# Saving Data to MongoDB Database from a Nodejs Application
This is the finished code from a tutorial that I wrote about saving data to a MongoDB database from a Node.js Application. You can read the tutorial to get step-by-step instructions on how to save data to a MongoDB database.

[You can read the tutorial here](http://www.jenniferbland.com/saving-data-to-mongodb-database-from-node-js-application-tutorial/)
